from distutils.core import setup

setup(
    name='PacketCrypto',
    version='0.0.1',
    description='a simple, small data packet encrypt and decrypt model. session support.',
    author='N0I0C0K@https://github.com/N0I0C0K',
    url='https://github.com/N0I0C0K/PacketCrypto',
    packages=['PacketCrypto']
)
